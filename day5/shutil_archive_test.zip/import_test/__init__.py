#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: Hero lws

print( "int the 'import_test\\__init__.py'")