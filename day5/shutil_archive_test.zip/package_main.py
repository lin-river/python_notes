#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: Hero lws

import import_test
#导入包的文件就是去执行包下面的__init__.py文件

#import_test.main    #无法找到main因为，调用包实际上是在调用__init__.py文件

import package_T
#运行 __init__.py --> Tt1 = "Tt1.py 所有的内容 -->
