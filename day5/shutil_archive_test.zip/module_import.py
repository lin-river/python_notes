#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: Hero lws

name = "linhaha"
def  say_hello():
    print("hello alinhaha!")

def eat():
    print( "in the module_import : eat")

def drink():
    print("in the module_import : drink")

def play():
    print("in the module_import : play")

print(" import moduel_import success!")