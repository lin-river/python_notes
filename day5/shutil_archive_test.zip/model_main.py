#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: Hero lws

print( "-------------- 第一个导入方法：import one -----------------\n")
#import module_import             #导入一个人模块
#print( module_import.name )
# module_import.say_hello()

print( "-------------- 第two个导入方法 : import more ----------------- \n")
# import module_import1 , module_import1

print( "-------------- 第 four 个导入方法 : from module import * -----------------\n")
from module_import import *     #导入module_import的所有方法，但不建议这么使用，慎用
#module_import.say_hello()       #报错：NameError: name 'module_import' is not defined
#因为上面的from import导入的是moduel_import内全部方法，而不是module_iport本身

eat()           #使用module_import的话直接调用方法名即可
#in the module_import : eat

def eat():                  #覆盖了1module_import导入的eat()代码
    print( "in the main")

eat()
#因为Python是一个解释性语言，当进行到from module_import import * 时，eat()被导入到main.p
# 当再进行到def eat()时，eat被重新定义，已不再是module_import的内的那个eat()

print( "-------------- 第 four 个导入方法 : from module import method as 别名-----------------\n")
from module_import import eat as work
work()

from module_import import eat,drink,play as work1       #以最后一个为准
work1()